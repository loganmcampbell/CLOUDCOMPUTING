in pagerank.v1.scala
----------------------
Use count() for force the evaluation so that the accumulator has the correct value



In pagerank.v2.scala
----------------------
Don't use accumulator