import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

object SparkPageRank {


  def main(args: Array[String]) {

    	val sparkConf = new SparkConf().setAppName("PageRank")
  	val iters = if (args.length > 0) args(0).toInt else 10
    	val sc = new SparkContext(sparkConf)
    	
	val lines = sc.textFile("input.txt")
    	val links = lines.map{ s =>
      		val parts = s.split("\\s+")
      	  	(parts(0), parts(1))
    	}.distinct().groupByKey()

	val nodes=lines.flatMap(line => line.split(" ")).distinct()
	val danglingNodes=nodes.subtract(links.keys).collect()	

        val linkList = links ++ sc.parallelize(for (i <- danglingNodes) yield (i, List.empty))  // add dangling nodes to the link list
	val nodeSize = linkList.count()  
        var ranks = linkList.mapValues(v => 1.0 / nodeSize)  
        for (i <- 1 to iters) {  
            val contribs = linkList.join(ranks).values.flatMap {  
                case (pageLinks, rank) => {  
                    val size = pageLinks.size  
                    if (size == 0) {  
                        List()  
                    } else {  
                        pageLinks.map(pageLink => (pageLink, rank / size))  
                    }  
                }  
            } 
            val danglingValue = 1- contribs.values.sum()  
            ranks = contribs.reduceByKey(_ + _, 3).mapValues[Double](p =>    //reduceByKey(_ + _) is equivalent to reduceByKey((x,y)=> x + y) prototype: reduceByKey(function, [numPartition])
                0.1 * (1.0 / nodeSize) + 0.9 * (danglingValue / nodeSize + p)  
            ) 
        }  
	ranks.sortBy(_._1, true).saveAsTextFile("output") //_._1: use _ as the wildcard parameter, _._1 is equivalent to x._1
    }  	
}
