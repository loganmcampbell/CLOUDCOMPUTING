rm -r output project target
sbt clean && sbt package
spark-submit  --master local[4] target/scala-2.10/simple-project_2.10-1.0.jar 9 

